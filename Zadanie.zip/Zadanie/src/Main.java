import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        while (true) {
            int randomGame = new Random().nextInt(3); // Losowy wybór gry
            switch (randomGame) {
                case 0:
                    playGuessNumber();
                    break;
                case 1:
                    playTicTacToe();
                    break;
                case 2:
                    playHangman();
                    break;
            }

            System.out.println("Czy chcesz zagrać ponownie czy wyłączyć grę? (Wpisz 'Stop Game' aby wyłączyć): ");
            Scanner scanner = new Scanner(System.in);
            String response = scanner.nextLine();
            if (response.equalsIgnoreCase("Stop Game")) {
                System.out.println("Koniec gry. Do zobaczenia!");
                break;
            }
        }
    }

    // Gra w zgadywanie liczby
    private static void playGuessNumber() {
        int targetNumber = new Random().nextInt(100) + 1;
        int attempts = 0;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Zgadnij liczbę od 1 do 100");

        while (true) {
            System.out.print("Podaj liczbę: ");
            int guess = scanner.nextInt();
            attempts++;

            if (guess < targetNumber) {
                System.out.println("Za mało. Spróbuj ponownie.");
            } else if (guess > targetNumber) {
                System.out.println("Za dużo. Spróbuj ponownie.");
            } else {
                System.out.println("Brawo! Zgadłeś liczbę w " + attempts + " próbach.");
                break;
            }
        }
    }

    // Gra w kółko-krzyżyk (Tic-Tac-Toe)
    private static void playTicTacToe() {
        char[][] board = {
                {' ', ' ', ' '},
                {' ', ' ', ' '},
                {' ', ' ', ' '}
        };

        int moves = 0;

        while (true) {
            printBoard(board);

            // Ruch gracza
            playerMove(board);
            moves++;

            if (checkWinner(board, 'X')) {
                printBoard(board);
                System.out.println("Gracz wygrywa!");
                break;
            } else if (moves == 9) {
                printBoard(board);
                System.out.println("Remis!");
                break;
            }

            // Ruch komputera
            computerMove(board);
            moves++;

            if (checkWinner(board, 'O')) {
                printBoard(board);
                System.out.println("Komputer wygrywa!");
                break;
            }
        }
    }

    private static void printBoard(char[][] board) {
        System.out.println("  0 1 2");
        for (int i = 0; i < 3; i++) {
            System.out.print(i + " ");
            for (int j = 0; j < 3; j++) {
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
    }

    private static boolean isValidMove(char[][] board, int row, int col) {
        return row >= 0 && row < 3 && col >= 0 && col < 3 && board[row][col] == ' ';
    }

    private static boolean checkWinner(char[][] board, char player) {
        for (int i = 0; i < 3; i++) {
            // Sprawdź poziome linie
            if (board[i][0] == player && board[i][1] == player && board[i][2] == player) {
                return true;
            }
            // Sprawdź pionowe linie
            if (board[0][i] == player && board[1][i] == player && board[2][i] == player) {
                return true;
            }
        }
        // Sprawdź przekątne
        if (board[0][0] == player && board[1][1] == player && board[2][2] == player) {
            return true;
        }
        if (board[0][2] == player && board[1][1] == player && board[2][0] == player) {
            return true;
        }
        return false;
    }

    private static void playerMove(char[][] board) {
        System.out.println("Twój ruch! Podaj wiersz (0-2) i kolumnę (0-2) oddzielone spacją: ");
        Scanner scanner = new Scanner(System.in);

        int row = scanner.nextInt();
        int col = scanner.nextInt();

        while (!isValidMove(board, row, col)) {
            System.out.println("Nieprawidłowy ruch. Spróbuj ponownie.");
            System.out.println("Podaj wiersz (0-2) i kolumnę (0-2) oddzielone spacją: ");
            row = scanner.nextInt();
            col = scanner.nextInt();
        }

        board[row][col] = 'X';
    }

    private static void computerMove(char[][] board) {
        Random random = new Random();

        System.out.println("Ruch komputera...");
        int row, col;

        do {
            row = random.nextInt(3);
            col = random.nextInt(3);
        } while (!isValidMove(board, row, col));

        board[row][col] = 'O';
    }


    // Gra w wisielca (Hangman)
    private static void playHangman() {
        String[] words = {"samochod", "komputer", "telefon", "dom", "ksiazka", "kot", "pies", "stol", "krzeslo", "drzewo"};
        String selectedWord = words[new Random().nextInt(words.length)];
        char[] guessedWord = new char[selectedWord.length()];
        for (int i = 0; i < selectedWord.length(); i++) {
            guessedWord[i] = '_';
        }

        int attemptsLeft = 6;
        Scanner scanner = new Scanner(System.in);

        System.out.println("Gra w wisielca - słowo do odgadnięcia nie zawiera polskich znaków.");
        System.out.println("Zgadnij słowo (słowo ma od 4 do 7 liter): ");

        while (attemptsLeft > 0) {
            System.out.println("Słowo: " + String.valueOf(guessedWord));
            System.out.println("Pozostałe próby: " + attemptsLeft);
            System.out.print("Podaj literę: ");
            char guess = scanner.next().charAt(0);

            boolean found = false;
            for (int i = 0; i < selectedWord.length(); i++) {
                if (selectedWord.charAt(i) == guess) {
                    guessedWord[i] = guess;
                    found = true;
                }
            }

            if (!found) {
                attemptsLeft--;
                System.out.println("Nieprawidłowa litera. Pozostałe próby: " + attemptsLeft);
            }

            if (String.valueOf(guessedWord).equals(selectedWord)) {
                System.out.println("Brawo! Zgadłeś słowo: " + selectedWord);
                break;
            }
        }

        if (attemptsLeft == 0) {
            System.out.println("Przegrałeś. Prawidłowe słowo to: " + selectedWord);
        }
    }
}